import boto3
import json

bucket_name = 'twibucket'
prefix = 'tweets/'

s3 = boto3.client('s3')

try:
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
    print("✅ S3 list response received.")
except Exception as e:
    print("❌ Error accessing S3:", e)
    exit()

file_uris = []
for obj in response.get('Contents', []):
    key = obj['Key']
    print("🔹 Found file:", key)
    if key.endswith('.json'):
        file_uris.append(f's3://{bucket_name}/{key}')

if not file_uris:
    print("⚠️ No .json files found in the specified folder.")
else:
    manifest = {
        "fileLocations": [
            {
                "URIs": file_uris
            }
        ],
        "globalUploadSettings": {
            "format": "JSON"
        }
    }

    with open('manifest1.json', 'w') as f:
        json.dump(manifest, f, indent=4)
    
    print("✅ Manifest file saved as 'manifest1.json'")
