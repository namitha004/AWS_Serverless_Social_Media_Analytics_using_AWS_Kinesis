import boto3
import pandas as pd
import json
import time

# Kinesis stream name
stream_name = 'twitter'

# Load CSV
try:
    df = pd.read_csv('twitter_dataset.csv')
except FileNotFoundError:
    print(f"\033[91mError: The file 'Twitter_Data.csv' was not found in the same directory.\033[0m")
    exit()
except Exception as e:
    print(f"\033[91mError reading CSV file: {e}\033[0m")
    exit()

# Optional: Add clean_text and category if not already present
if 'clean_text' not in df.columns:
    df['clean_text'] = df['Text'].fillna('').str.lower().str.replace(r'[^a-z\s]', '', regex=True)

if 'category' not in df.columns:
    def classify_sentiment(text):
        if "modi" in text and ("good" in text or "support" in text or "development" in text):
            return 1.0
        elif "modi" in text and ("bad" in text or "against" in text or "corrupt" in text):
            return 0.0
        else:
            return -1.0  # neutral or unknown
    df['category'] = df['clean_text'].apply(classify_sentiment)

# Create Kinesis client
try:
    kinesis_client = boto3.client('kinesis', region_name='us-east-1')
    print(f"\033[94mInfo: Successfully created Kinesis client for region 'us-east-1'.\033[0m")
except Exception as e:
    print(f"\033[91mError creating Kinesis client: {e}\033[0m")
    exit()

# Send each row as a record to Kinesis
print(f"\033[94mInfo: Sending data to Kinesis stream '{stream_name}'...\033[0m")
for index, row in df.iterrows():
    data = {
        "id": row.get('Tweet_ID', ''),
        "created_at": row.get('Timestamp', ''),
        "text": row.get('Text', ''),
        "retweet_count": row.get('Retweets', 0),
        "favorite_count": row.get('Likes', 0),
        "lang": "",  # Not available in your CSV
        "hashtags": "",  # Not available
        "user_screen_name": row.get('Username', ''),
        "user_followers_count": 0,  # Not available
        "user_location": "Unknown",  # Not available
        "user_verified": False,  # Not available
        "clean_text": row.get('clean_text', ''),
        "category": row.get('category', -1.0)
    }

    json_data = json.dumps(data)

    try:
        response = kinesis_client.put_record(
            StreamName=stream_name,
            Data=json_data.encode('utf-8'),
            PartitionKey=str(index)
        )
        print(f"\033[92m✔ Tweet sent to Kinesis:\033[0m {json_data} \033[90m(Sequence Number: {response['SequenceNumber']})\033[0m")
        time.sleep(0.5)  # simulate real-time streaming
    except Exception as e:
        print(f"\033[91mError sending record {index} to Kinesis: {e}\033[0m")
        print(f"\033[91mFailed data: {json_data}\033[0m")

print(f"\033[94mInfo: Finished sending all records to Kinesis stream '{stream_name}'.\033[0m")
