import boto3
import json

# Your S3 bucket name and processed folder
bucket_name = 'twibucket'
prefix = 'processed/'

# Initialize S3 client
s3 = boto3.client('s3')

try:
    # List objects in the 'processed/' folder
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
    print("✅ S3 list response received.")
except Exception as e:
    print("❌ Error accessing S3:", e)
    exit()

# Gather all .json file URIs
file_uris = []
for obj in response.get('Contents', []):
    key = obj['Key']
    print("🔹 Found file:", key)
    if key.endswith('.json'):
        file_uris.append(f's3://{bucket_name}/{key}')

if not file_uris:
    print("⚠️ No .json files found in the specified folder.")
else:
    # Construct the manifest
    manifest = {
        "fileLocations": [
            {
                "URIs": file_uris
            }
        ],
        "globalUploadSettings": {
            "format": "JSON"
        }
    }

    # Save manifest file
    with open('sentiment-manifest1.json', 'w') as f:
        json.dump(manifest, f, indent=4)
    
    print("✅ Manifest file saved as 'sentiment-manifest1.json'")
